const LEVELS = {
  foundation: {
    label: 'FOUNDATION', badge: 'foundation-badge', time: '3–5 min', title: 'Add two vectors',
    text: 'A vector tells us how far to move horizontally and vertically. Add the matching components to find the combined movement.',
    equation: 'a = (2, 1), &nbsp; b = (3, 4)<br><span>Find a + b.</span>', context: 'Think: horizontal + horizontal, vertical + vertical.', answer: [5, 5],
    hint: 'Add the first numbers: 2 + 3. Then add the second numbers: 1 + 4. Keep the two results in the same order.',
    solution: '<p><b>Step 1:</b> Add the x-components: 2 + 3 = 5.</p><p><b>Step 2:</b> Add the y-components: 1 + 4 = 5.</p><p><b>Answer:</b> a + b = (5, 5).</p>',
    prompt: 'Solve the vector addition problem a=(2,1), b=(3,4). The answer is (5,5). Explain at a beginner level with two simple steps. Do not change the given numbers.'
  },
  standard: {
    label: 'STANDARD', badge: 'standard-badge', time: '5–7 min', title: 'Find a resultant vector',
    text: 'The resultant vector is the sum of two vectors. Add corresponding components, then calculate its magnitude using the Pythagorean theorem.',
    equation: 'u = (−2, 5), &nbsp; v = (6, −1)<br><span>Find u + v and |u + v|.</span>', context: 'First find the resultant components. Then use |(x, y)| = √(x² + y²).', answer: [4, 4, Math.sqrt(32)],
    hint: 'Be careful with negative numbers. The resultant is (−2 + 6, 5 + (−1)). For the magnitude, square each resultant component, add, and take the square root.',
    solution: '<p><b>Step 1:</b> Add components: u + v = (−2 + 6, 5 − 1) = (4, 4).</p><p><b>Step 2:</b> Magnitude = √(4² + 4²) = √32 = 4√2 ≈ 5.66.</p><p><b>Answer:</b> resultant (4, 4), magnitude 4√2.</p>',
    prompt: 'Explain the solution to u=(-2,5), v=(6,-1): find the resultant and its magnitude. Correct result is (4,4), magnitude sqrt(32)=4sqrt(2)≈5.66. Explain component addition and magnitude formula clearly.'
  },
  advanced: {
    label: 'ADVANCED', badge: 'advanced-badge', time: '7–10 min', title: 'A vector in a real-world model',
    text: 'A drone travels according to two displacement vectors. Use vector addition to find its net displacement, then calculate how far it is from its starting point.',
    equation: 'd₁ = (−3, 4) km, &nbsp; d₂ = (7, 2) km<br><span>Find the net displacement and its distance from the start.</span>', context: 'Treat east as positive x and north as positive y. Distance from the start is the magnitude of the net vector.', answer: [4, 6, Math.sqrt(52)],
    hint: 'Add the east-west components and the north-south components separately. The net vector is (−3 + 7, 4 + 2). Its length is √(x² + y²).',
    solution: '<p><b>Step 1:</b> Net displacement = (−3 + 7, 4 + 2) = (4, 6) km.</p><p><b>Step 2:</b> Distance from start = √(4² + 6²) = √52 = 2√13 ≈ 7.21 km.</p><p><b>Interpretation:</b> The drone ends 4 km east and 6 km north of its starting point, about 7.21 km away in a straight line.</p>',
    prompt: 'Explain this drone displacement problem. d1=(-3,4) km and d2=(7,2) km. Correct net displacement (4,6) km and distance sqrt(52)=2sqrt(13)≈7.21 km. Explain vector components and real-world interpretation. Do not alter these values.'
  }
};
let currentLevel = 'foundation';
const $ = id => document.getElementById(id);
const clean = s => String(s).replace(/[−–]/g, '-').replace(/\s/g, '').replace(/[()[\]]/g, '');
function renderLevel(level) {
  currentLevel = level; const p = LEVELS[level];
  document.querySelectorAll('.level-tab').forEach(btn => { const active = btn.dataset.level === level; btn.classList.toggle('active', active); btn.setAttribute('aria-selected', String(active)); });
  $('levelBadge').textContent = p.label; $('levelBadge').className = `level-badge ${p.badge}`; $('timeLabel').textContent = p.time;
  $('problemTitle').textContent = p.title; $('problemText').textContent = p.text; $('problemEquation').innerHTML = p.equation; $('problemContext').textContent = p.context;
  $('answerInput').value = ''; $('feedback').hidden = true; $('hintPanel').hidden = true; $('solutionPanel').hidden = true; $('aiResponse').hidden = true;
  $('answerLabel').innerHTML = level === 'standard' ? 'Your answer <span>(resultant x, y; magnitude)</span>' : level === 'advanced' ? 'Your answer <span>(net x, y; distance)</span>' : 'Your answer <span>(write as x, y)</span>';
  $('answerInput').placeholder = level === 'foundation' ? 'e.g. 5, 5' : 'e.g. 4, 4, 5.66';
  $('inputHelp').textContent = level === 'foundation' ? 'You can type (5,5), 5, 5, or [5,5].' : 'Separate each value with a comma. Exact radicals or decimals are accepted approximately.';
  $('aiQuestion').value = ''; $('aiStatus').textContent = 'Ask for a hint, another example, or a simpler explanation.';
}
document.querySelectorAll('.level-tab').forEach(btn => btn.addEventListener('click', () => renderLevel(btn.dataset.level)));
$('hintBtn').addEventListener('click', () => { $('hintPanel').innerHTML = `<b>Hint</b><p>${LEVELS[currentLevel].hint}</p>`; $('hintPanel').hidden = false; });
$('solutionBtn').addEventListener('click', () => { $('solutionPanel').innerHTML = `<b>Worked solution</b>${LEVELS[currentLevel].solution}`; $('solutionPanel').hidden = false; });
function parseNumbers(value) { const normalized = value.replace(/[−–]/g, '-').match(/-?\d+(?:\.\d+)?/g); return normalized ? normalized.map(Number) : []; }
$('answerForm').addEventListener('submit', e => {
  e.preventDefault(); const vals = parseNumbers($('answerInput').value); const expected = LEVELS[currentLevel].answer; let ok = false;
  if (currentLevel === 'foundation') ok = vals.length === 2 && vals.every((v,i) => v === expected[i]);
  else ok = vals.length >= 3 && vals.slice(0,2).every((v,i) => v === expected[i]) && Math.abs(vals[2] - expected[2]) < 0.03;
  const box = $('feedback'); box.hidden = false; box.className = `feedback ${ok ? 'good' : 'try'}`;
  box.innerHTML = ok ? '<b>Correct — great work!</b><br>You found the right result. Open the worked solution to review each step.' : `<b>Not quite yet.</b><br>${currentLevel === 'foundation' ? 'Remember to add x-components together, then y-components together. Your answer should contain two numbers.' : 'Check the two component sums first, then calculate the magnitude using √(x² + y²). Enter x, y, magnitude (for example: 4, 4, 5.66).'} You can use a hint and try again.`;
});
async function askAI(question) {
  if (!question.trim()) { $('aiStatus').textContent = 'Please type a question or choose one of the suggestions above.'; return; }
  $('askAiBtn').disabled = true; $('askAiBtn').innerHTML = '<span>✦</span> Thinking…'; $('aiStatus').textContent = 'Generating a level-specific explanation…'; $('aiResponse').hidden = true;
  try {
    const res = await fetch('/.netlify/functions/ai-tutor', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ level: currentLevel, problem: LEVELS[currentLevel].prompt, question }) });
    const data = await res.json(); if (!res.ok) throw new Error(data.error || 'AI request failed.');
    $('aiResponse').textContent = data.answer; $('aiResponse').hidden = false; $('aiStatus').textContent = 'AI response generated. Check the math and use it as a learning guide.';
  } catch (err) {
    $('aiResponse').textContent = err.message.includes('not configured') ? 'AI is not connected yet. The three learning levels, answer checking, hints, and worked solutions still work. To enable AI, add GEMINI_API_KEY in Netlify → Site configuration → Environment variables, then redeploy.' : `Could not reach the AI service. ${err.message} The built-in hints and worked solutions are still available.`;
    $('aiResponse').hidden = false; $('aiStatus').textContent = 'AI connection unavailable.';
  } finally { $('askAiBtn').disabled = false; $('askAiBtn').innerHTML = '<span>✦</span> Ask AI <span class="ai-arrow">→</span>'; }
}
$('askAiBtn').addEventListener('click', () => askAI($('aiQuestion').value));
$('aiQuestion').addEventListener('keydown', e => { if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) askAI($('aiQuestion').value); });
document.querySelectorAll('.prompt-chip').forEach(btn => btn.addEventListener('click', () => { $('aiQuestion').value = btn.dataset.prompt; askAI(btn.dataset.prompt); }));
renderLevel('foundation');
